import bcrypt
print(bcrypt.hashpw(b"supersecretpassword", bcrypt.gensalt()))