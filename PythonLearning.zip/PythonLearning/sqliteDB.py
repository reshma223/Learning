import sqlite3

#define database connection and cursor

connection=sqlite3.connect('store_transaction.db')

cursor=connection.cursor()

#create stores tables

command1='''CREATE TABLE IF NOT EXISTS
stores(stores_id INTERGER PRIMARY KEY, location TEXT)'''

cursor.execute(command1)

#CREATE PURCHASE TABLE

command2='''CREATE TABLE IF NOT EXISTS
purchases(purchase_id INTEGER PRIMARY KEY, store_id INTEGER, total_cost FLOAT, FOREIGN KEY(store_id) REFERENCES stores(store_id))'''
cursor.execute(command2)

#add to stores
cursor.execute('INSERT INTO stores VALUES(21,"Minneapolis,MN")')
cursor.execute('INSERT INTO stores VALUES(22,"Seattle,WA")')
cursor.execute('INSERT INTO stores VALUES(23,"Cleveland,OH")')

#add to purchases
cursor.execute('INSERT INTO purchases VALUES(54,21,15.49)')
cursor.execute('INSERT INTO purchases VALUES(23,64,21.12)')

#get results
#cursor.execute('SELECT * FROM stores')
cursor.execute('SELECT * FROM purchases')

results=cursor.fetchall()
print(results)

# cursor.execute('SELECT * FROM purchases')

# update
# cursor.execute('UPDATE purchases SET total_cost=3.99 WHERE purchase_id=54') 


#delete
#cursor.execute('DELETE FROM purchases WHERE purchase_id=23')

# connection.commit()
# cursor.execute('SELECT * FROM purchases WHERE purchase_id=54')
# print(cursor.fetchall())

# connection.close()

#cursor.execute('select * from purchases')
