import sqlite3

conn=sqlite3.connect("school.db")
conn.execute('''
    Create table student(
             st_id INTERGER PRIMARY KEY,
             st_name VARCHAR(20),
             st_class VARCHAR(20),
             st_email VARCHAR(20)

             )
             
             ''')
conn.close()