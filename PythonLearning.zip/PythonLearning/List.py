#List Method
l=[90,4.5, 1,2,3,4,5,5,5]
print(l)
#l.append(38) #append is a method to add an element at the end of the list
# l.sort() 
# print(l)
#l.sort(reverse=True)
#l.reverse()
# print(l.index(3))  #it gived the index of 3 which is in 2nd position
# print(l.count(5))

# m=l.copy()
# m[0]=0
# print(l,m)
  
# l.insert(1,49)

n=[100,200,300]
#l.extend(n)
k=l+n
print(k)
print(l)

# l=[3,4,5]
# print(l)
# print(type(l))

# marks=[3,4,5,"Harry",True,5.6]
# print(marks)
# print(type(marks))
# print(marks[0])
# print(marks[1])
# print(marks[2])

# print(marks[-3]) #Negative Index
# print(marks[len(marks)-3]) #Positive Index  length-Negative index=6-3=3
# print(marks[6-3])
# print(marks[3])

# if "Harry" in marks:
#     print("Yes")
# else:
#     (print("No"))

# if "arry" in "Harry":
#     print("Yes")

# print(marks)
# print(marks[:]) #print(marks[0:len(marks)])
# print(marks[1:])
# print(marks[1:-1])
# print(marks[1:5])

# print(marks[0:6])
# print(marks[0:6:2]) #here last is jump index

# #list compherension
# lst=[i for i in range(10) ]
# print(lst)

# lst=[i for i in range(10) if i%2==0]
# print(lst)


