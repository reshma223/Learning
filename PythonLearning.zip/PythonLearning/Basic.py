print("Hello, World!")

#Python editor version
import sys
print("Python version")
print (sys.version)

print("jjvfmd"); print("jfjfndjfn")

#Variables
#Variables are containers for storing data values. Variable is created the moment you first assign a value to it. 
#Variables are something where the data is stored. For eg: x=5, here x is a variable that contains the value 5.
x=5
y="John"
x="Sally"
print(x)
print(y)

x=str(3)
y=int(3)
z=float(3)
print(x,y,z)

#To find the data type of a variable, use the type() function:
print(type(x))
print(type(y))
print(type(z))

x=4       
X="Sally" 
print(x)

#Variable Names
#Camel Case first small 
myVariableName = "John"
#Pascal Case first word all capital
MyVariableName= "John"
#Snake Case all small with underscore
my_variable_name = "John"
print(myVariableName)
print(MyVariableName)
print(my_variable_name)

#Assign Value to Multiple Variables
x,y,z="Orange","Banana","Cheery"
print(x)
print(y)
print(z)

x=y=z="Orange"
print(x)
print(y)
print(z)   

fruits=[1,2,3]
x,y,z=fruits
print(x+y+z)

#Global Variables
x="awesome"
def my_func():
    global x
    x="fantastic"
    #print("Python is " + x)
my_func()
print("Python is " + x)

#Data Types
x=type("Hello")
print(x)

x={"name":"John","age":30}
print(type(x))

x={"apple","banana"}
print(type(x))
print(x)

#Numbers
x=1
y=2.3
z=2j+2
print(type(x))
print(type(y))
print(type(z))
a=float(x)
b=complex(y)
print(b)

#Casting- in integer put integer,float,string
x=int(1)
y=int(1.6)
z=int("3")
print(x,y,z)

x=float(1)
y=float(1.6)
z=float("3")
w=float("3.5")
print(x,y,z,w)

x=str("s1")
y=str(1.6)
z=str(3)
print(x,y,z)

#Strings
print("hello,world")
a="Hello"
print(a)
print(a[0])
print(len(a))

for x in "banana":
    print(x)

#check string
b="Hello, World!"
print("Hello" in b)
print("World" not in b)
#Using If
if "Hello" in b:
    print("Yes, 'Hello' is present.")

if "rest" not in b:
    print("No, 'rest' is NOT present.")

print(b[2:5])
print(b[:5])
print(b[2:])
print(b[-5:-2]) 

print(b.upper())
print(b.lower())
print(b.capitalize())
print(b.strip())
print(b.replace("H","J"))
print(b.split(","))

#Boolean
a=23
b=2
if b>=a:
    print("a is greater than b")
else:
    print("a is not greater than b")

#Operator
print(10+5)

sum1=100+50
sum2=sum1+250
sum3=sum2+sum2
print(sum3)

a=10
b=5
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)
print(a**b)
print(a//b) 


print(a==b)
print(a!=b)
print(a>b)
print(a<b)
print(a>=b)
print(a<=b)

print("Logical Operators")
print(a>0 and a<10)
print(a>0 or a<10)
print(not(a>0 and a<10))   

print("Identify Operators")
x=["apple","banana"]
y=["apple","banana"]
z=x
print(x is z)
print(x is y)
print(x==y)
print(x is not y)

print("Membership Operators")
print(6&3)
print(6|3)
print(6^3)
print(~3)       

list=["apple","banana","cherry"]
print(list[-1])