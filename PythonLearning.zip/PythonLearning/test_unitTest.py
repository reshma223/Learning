from unitTest import get_weather
from unitTest import add,divide
from unitTest import UserManager
from unitTest import Database
from unitTest import is_prime
from unitTest import get_weather11
import pytest

def test_get_weather(mocker):
    #Mock request.get
    mock_get = mocker.patch('unitTest.requests.get')

    #set return rules
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = {"temperature": 25, "condition": "Sunny"}

    #call the function
    result = get_weather11("London")

    #assert the result
    assert result == {"temperature": 25, "condition": "Sunny"}
    mock_get.assert_called_once_with("http://api.weatherapi.com/v1/London")





# @pytest.mark.parametrize("num, expected", [
#     (2, True),
#     (3, True),
#     (4, False),
#     (5, True),
#     (16, False),
#     (17, True),
#     (18, False),
#     (19, True),
#     (20, False)
# ])
# def test_is_prime(num, expected):
#     # assert is_prime(7) == True
#     assert is_prime(num) == expected





# @pytest.fixture

# def db():
#     """Provides a fresh instances of Database class and clean up after the test."""
#     database = Database()
#     yield database #Provide the fixture instances
#     database.data.clear() #Clean up after the test
 
# def test_add_user(db):
#     db.add_user(1, "Alice")
#     assert db.get_user(1) == "Alice"

# def test_add_duplicate_user(db):
#     db.add_user(1, "Alice")
#     with pytest.raises(ValueError, match="User already exists"):
#         db.add_user(1, "Bob")

# def test_delete_user(db):
#     db.add_user(2, "Bob")
#     db.delete_user(2)
#     assert db.get_user(2) is None

# @pytest.fixture
# def usermanager():
#     """Create a fresh instance of UserManager before each test."""
#     return UserManager()

# def test_add_user(usermanager):
#     assert usermanager.add_user("John Doe", "John@example.com") == True
#     assert usermanager.add_user("John Doe") == "John@example.com"

# def test_add_duplicate_user(usermanager):
#     usermanager.add_user("John Doe", "John@example.com")
#     with pytest.raises(ValueError):
#         usermanager.add_user("John Doe", "another@example.com")






# def test_add():
#     assert add(2,3) ==5, "2+3 should be 5"
#     assert add(-1,1) == 0, "-1+1 should be 0"
#     assert add(0,0) == 0 , "0+0 should be 0"

# def test_divide():
#     with pytest.raises(ValueError,match="Cannot divide by zero"):
#         divide(10,0)
    



# def test_get_weather():
#     assert get_weather(25) == "Hot" 

# def test_get_weather1():
#     assert get_weather(25) == "cold" 
#      #assert tells u whether the output is correct or not