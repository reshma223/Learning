# a=int(input("Enter the age:"))
# print("Your Age is:",a)

# if(a>18):
#     print("You can Drive")
# else:
#     print("You cannot Drive")

# apple_price=int(input("Enter a apple price:"))
# budget=200
# if(budget-apple_price<50):
#     print("You can buy the item")
# elif(budget-apple_price<100):
#     print("You can buy the item and gift someone")

# else:
#     print("You cannot buy the item")

# num = int(input("Enter a number: "))
# if (num < 0):
#     print("Number is negative.")
# elif (num == 0):
#     print("Number is Zero.")
# elif(num==999):
#     print("Number is Special.")
# else:
#     print("Number is positive.")

#Nested If
#num=18
num=int(input("Enter a number: "))
if(num<0):
    print("No. is negative")
elif(num>0):
    if(num<=10):
        print("Number is betn 1 to 10")
    elif(num<=20):
        print("no if bet 11 to 20 ")
    else:
        print("no if greater than 20")
else:
    print("Number is Zero")