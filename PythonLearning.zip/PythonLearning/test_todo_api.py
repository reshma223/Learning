import requests

ENDPOINTS ="https://todo.pixegami.io/"


def test_can_create_task():
    payload={
  "content": "test content",
  "user_id": "test user id",
  "task_id": "test task id",
  "is_done": False
}
    response=requests.put(ENDPOINTS+"create-task",json=payload)
    assert response.status_code == 200
    data=response.json()
    print(data)







# def test_can_call_endpoints():
#     response = requests.get(ENDPOINTS)
#     assert response.status_code == 200


# response = requests.get(ENDPOINTS)
# print(response)

# data=response.json()
# print(data)
# status_code=response.status_code
# print(status_code)

