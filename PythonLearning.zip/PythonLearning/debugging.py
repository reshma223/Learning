# a=12
# b=50
# if b>a:
#     print("b is greater than a")

# def greeting():
#     count=3
#     print("Hello, World!")
#     count=count+1
#     print("Count is:", count)
# greeting()

# def greeting2():
#     print("I am greeting2 function")
# greeting2()

counter=1
while counter<=5:
    print(counter)
    counter=counter+1
