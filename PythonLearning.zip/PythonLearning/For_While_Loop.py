#Loop

# name="Abhishek"
# for i in name:
#     print(i, end=",")

# colors=("Red","Green","Blue")
# for colours in colors:
#     print(colours)
#     for i in colours:
#         print(i)


# for i in range(6,12,2):
#     print(i+1)

#While
# i=0
# while(i<):
#     print(i)
#     i=i+1

# i=int(input("Enter a number: "))

# while(i<50):
#     i=int(input("Enter a number: "))
#     print(i)
# print("DONE")

count=5
while(count>0):
    print(count)
    count=count-1
else:
    print("DONE")








