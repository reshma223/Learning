# keys=word
# value=meaning

# dic={
# }

#method
#Update
ep1={123:45, 567:89, 890:12}
ep2={234:56, 678:90}
#ep1.update(ep2)
#ep1.clear()
#ep1.pop(123)  #delete key 123
#ep1.popitem()  #delete last item
del ep1[123]
print(ep1)

# empt={}
# print(empt)








# dic={
#     "Harry":"Human Being",
#     "Spoon":"Object",
#     123:"Neha",
#     90:"Kabir"
# }
# print(dic["Harry"])
# print(dic[123])

# info={'name':'Neha', 'age': 25, 'eligibility': True}
# print(info)
# print(info['name'])
# print(info.get('name'))
# print(info.get('name2'))
# print(info.get('eligibility'))
# #to access all keys
# print(info.keys())
# print(info.values())

# for key in info.keys():
#     print(f"The values corresponding to {key} is {info[key]}")


# print(info.items())

# for key,value in info.items():
#     print(f"The value corresponding to {key} is {value}")